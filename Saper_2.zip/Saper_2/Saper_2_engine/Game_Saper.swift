//
//  Game_Saper.swift
//  Saper_2
//
//  Created by Alex on 2020-01-29.
//  Copyright © 2020 Alex. All rights reserved.
//

import Foundation

class GameSaper{
    private var boardGame : Board!
    
    private let bombsQuantity: Int
    private let rows: Int
    private let columns: Int
    
    init(rows: Int = 10, columns: Int = 10, bombsQuantity: Int = 15){
        self.bombsQuantity = bombsQuantity
        self.rows = rows
        self.columns = columns
        
        boardGame = Board(rows: rows, columns: columns, bombsQuantity: bombsQuantity )
        
    }
    
    func setViewBoard(viewBoard: ViewBoard)
    {
        
            viewBoard.board = boardGame
            viewBoard.covered = false
        
    }
    
    
    
    func printBoards() {
        print ("Game")
        boardGame.printBoard();
        print(String(repeating: "-", count: columns+10))
    }
    
    public func bombsAutoSetup()->Bool {
            var board = boardGame
            
            var i=1
            while !(board!.bombsAutoSetup()) {
                board = Board(rows: self.rows, columns: self.columns, bombsQuantity: self.bombsQuantity)
                print ("powtówne losowanie ")
                i+=1
                guard i<10 else {
                    return false
                }
            }
            return true
        }
    public func pick(rowNumber: Int, colNumber: Int, pick: Bool)->Bool {
                return boardGame.pick(rowNumber: rowNumber, colNumber: colNumber, pick: pick)
        }
    //    public func shot(who: Who, rowName: String, colName: String)->Bool {
    //        if(who == .player) {
    //            return boardOpponent.shot(rowName: rowName, colName: colName)
    //        }
    //        else {
    //            return boardPlayer.shot(rowName: rowName, colName: colName)
    //        }
    //    }
    
    
}
