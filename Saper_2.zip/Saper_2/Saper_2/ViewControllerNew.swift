//
//  ViewControllerNew.swift
//  Saper_2
//
//  Created by Alex on 2020-02-02.
//  Copyright © 2020 Alex. All rights reserved.
//

import Cocoa

class ViewControllerNew: NSViewController{
    
    @IBOutlet var TextFieldBombs: NSTextField!
    
    @IBOutlet var ButtonStart: NSButton!
    
    var viewController : ViewController?
        
        override func viewDidLoad() {
            super.viewDidLoad()
            //
            //        let sMask = self.view.window
            //        self.view.window?.styleMask.remove(.resizable)
            //        self.view.window?.styleMask.remove(.closable)
            
            //        self.view.window?.styleMask.remove(.)
            
            
            TextFieldBombs.delegate = (self as! NSTextFieldDelegate)
            
            viewController = (NSApplication.shared.mainWindow?.contentViewController as! ViewController)
            
            TextFieldBombs.stringValue = String(viewController!.bombsQuantity)
            
        }
    
    
    @IBAction func ButtonStart_Click(_ sender: Any) {
        self.view.window?.performClose(nil)
        viewController!.prepareNewGame()
    }
    
    
        
    }
    extension ViewControllerNew:NSTextFieldDelegate {
        func controlTextDidChange(_ obj: Notification) {
            //        let field = obj.object as! NSTextField
            //
            //        let value = Int(field.stringValue)
            //
            //        guard value != nil && value! >= 5 && value! <= 15 else {
            //            field.backgroundColor = NSColor.red
            //            ButtonStart.isEnabled = false
            //            return
            //        }
            
            let bombsQuantity = Int(TextFieldBombs.stringValue)
            
            
            ButtonStart.isEnabled = true
            
            if bombsQuantity != nil && bombsQuantity! >= 5 && bombsQuantity! <= 99 {
                TextFieldBombs.backgroundColor = NSColor.textBackgroundColor
                viewController!.bombsQuantity = bombsQuantity!
            }
            else {
                TextFieldBombs.backgroundColor = NSColor.red
                ButtonStart.isEnabled = false
            }
            
        

        }
    
}
