//
//  ViewController.swift
//  Saper_2
//
//  Created by Alex on 2020-01-28.
//  Copyright © 2020 Alex. All rights reserved.
//

import Cocoa

class ViewController: NSViewController {

    @IBOutlet var ViewBoardGame: ViewBoard!
    
    
    var rows = 10
    var cols = 10
    var bombsQuantity = 15

    private var myGame: GameSaper!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        //prepareNewGame()
    }
    
    func prepareNewGame() {
        let newGame = GameSaper(rows: rows, columns: cols, bombsQuantity: bombsQuantity)
        
        guard newGame.bombsAutoSetup()
            else {
                let alert = NSAlert()
                alert.messageText = "Autosetup failed. Change parameters in \"New game\" window."
                alert.runModal()
                return
        }
        
        myGame = newGame
        myGame.setViewBoard(viewBoard: ViewBoardGame)
        
        myGame.printBoards()
        
        ViewBoardGame.needsDisplay = true
    }
    
    func playerClick(_ x: Int, _ y: Int, _ pick: Bool) {
        if !myGame.pick(rowNumber: y, colNumber: x, pick: pick) {
            
        }
        else
        {
            
        }
        
//        myGame.printBoards()
    
            
            let alert = NSAlert()
//            alert.addButton(withTitle: "TAK")
//            alert.addButton(withTitle: "NIE")
    
//            alert.buttons[0].highlight(true)
//            alert.buttons[1].highlight(true)
    
//            alert.showsSuppressionButton = true
//            alert.suppressionButton?.title = "Czy zapamiętać ustawienia?"
    
            
            alert.runModal()
//            let response = alert.runModal()

//            //Sprawdzanie odpowiedzi - jeśli by była potrzeba
//            if response==NSApplication.ModalResponse.alertFirstButtonReturn {
////                print("1")
//            }
//            else if response==NSApplication.ModalResponse.alertSecondButtonReturn {
////                print("2")
//            }
//            else if response==NSApplication.ModalResponse.alertThirdButtonReturn {
////                print("3")
//            }
        
    }
    
    override var representedObject: Any? {
        didSet {
        // Update the view, if already loaded.
        }
    }
}

