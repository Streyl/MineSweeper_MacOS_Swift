//
//  Board.swift
//  Saper_2
//
//  Created by Alex on 2020-01-29.
//  Copyright © 2020 Alex. All rights reserved.
//

import Foundation

class Board{
    private let columns: Int
    private let rows: Int
    var Rows: Int {
        get{
            return rows
        }
    }
    var Columns: Int {
        get{
            return columns
        }
    }
    private var board: [[CellContentType]]
    var Board: [[CellContentType]]{
        get{
            return board
        }
    }
    
    private var bombsQuantity: Int
    
    enum CellContentType {
        case empty, bomb, hitEmpty, hitBomb
    }
    
    init (rows: Int, columns: Int, bombsQuantity: Int)
    {
        self.rows = rows
        self.columns = columns
        self.bombsQuantity = bombsQuantity
        
        self.board = Array(repeating: Array(repeating: CellContentType.empty, count: self.columns), count: self.rows)
    }
    
    func printBoard(covered: Bool=false) {
        let maxRowHeaderLenght = (rows+1).determineNumberOfDigits()
        
        let borderLine = "+\(String(repeating:"-", count: columns*2+3+maxRowHeaderLenght*2))+"
        
        var colHeader = ""
        
        for col in 0..<columns {
            colHeader += getColName(colNumber: col)+" "
        }
        colHeader = "|" + String(repeating: " ", count: 2+maxRowHeaderLenght) + colHeader + String(repeating: " ", count: 1+maxRowHeaderLenght) + "|"
        
        print(borderLine)
        print(colHeader)
        
        for row in 0..<rows {
            var line = ""
            for col in 0..<columns {
                switch (board[row][col],covered){
            
                case (.empty, _):
                    line += "  "
                case (.bomb, true):
                    line += "  "
                case(.bomb, false):
                    line += "_ "
                case (.hitEmpty, _):
                    line += ". "
                case (.hitBomb, _):
                    line += "X "
                }
            }
            print("| \(getRowName(rowNumber: row).leftPadding(toLength: maxRowHeaderLenght)) \(line)\(getRowName(rowNumber: row).leftPadding(toLength: maxRowHeaderLenght)) |")
        }
        
        print(colHeader)
        print(borderLine)
        
        
        
        
    }
    
    private func getRowName(rowNumber r: Int) -> String
    {
        return String (r+1)
    }
    
    private func getColName(colNumber c: Int) -> String{
        String(UnicodeScalar(Int(UnicodeScalar("A").value) + c) ?? "A")
    }
    
    private func getRowNumber(rowNumber r:String) -> Int {
        return Int(r)! - 1
    }
    
    private func getColNumber(colNumber c:String) -> Int {
        return Int(UnicodeScalar(c)!.value) - Int(UnicodeScalar("A").value)
    }
    private func isCorrectField(rowNumber: Int, colNumber: Int) -> Bool {
        if rowNumber>=0 && rowNumber<rows && colNumber>=0 && colNumber<columns {
            return true
        }
        return false
    }
    private func isEmpty(rowNumber: Int, colNumber: Int) -> Bool {
        if(board[rowNumber][colNumber] == CellContentType.empty) {
            return true
        }
        return false
    }
    
    private func isBomb(rowNumber: Int, colNumber: Int) -> Bool {
        if(board[rowNumber][colNumber] == CellContentType.bomb) {
            return true
        }
        return false
    }
    
    private func placeBomb(rowNumber: Int, colNumber: Int)->Bool {
        var fields:[(Int, Int)] = Array()
        for (r,c) in fields {
            board[r][c] = CellContentType.bomb
        }
        //printBoard()
        return true
    }			        
    
    public func bombsAutoSetup() -> Bool {
        var maxTries = 1000
        var index = 1
        while index <= bombsQuantity {
            var row: Int
            var col: Int
            while(true) {
                row = Int.random(in: 0..<rows)
                col = Int.random(in: 0..<columns)
                maxTries -= 1
                if maxTries < 0
                {
                    print("Nie udało się wylosować!!!")
                    printBoard()
                    return false
                }
                //print(maxTries)
                //printBoard()
                if(self.placeBomb(rowNumber: row, colNumber: col))
                {
                    index = index + 1
                    break
                    
                }
            }
        }
        print("Wylosowane za \(1000-maxTries) razem")
        return true
    }
    
        public func pick(rowNumber: Int, colNumber: Int, pick: Bool)->Bool {
            //strzał poza planszą
            guard rowNumber>=0 && rowNumber<rows && colNumber>=0 && colNumber<columns else
            {
                return true
            }
            if pick {
                switch board[rowNumber][colNumber] {
                case .empty:
                    board[rowNumber][colNumber] = .hitEmpty
                    break
                case .bomb:
                    board[rowNumber][colNumber] = .hitBomb
                    return true
                //break
                case .hitEmpty,.hitBomb:
                    return true
                }
                return false
            }
            else {
                switch board[rowNumber][colNumber] {
                case .empty:
                    board[rowNumber][colNumber] = .hitEmpty
                    break
                
                case .bomb:
                    board[rowNumber][colNumber] = .hitBomb
                    break
                
                case .hitEmpty, .hitBomb:
                    break
                }
                return true
            }
        }
    
}
